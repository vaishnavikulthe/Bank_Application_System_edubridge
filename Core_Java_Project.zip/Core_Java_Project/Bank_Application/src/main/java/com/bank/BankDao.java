package com.bank;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Date;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class BankDao {
	Scanner scanner = new Scanner(System.in);
	DataBase dataBase = new DataBase();
	Validation validation = new Validation();
	Bank_Controller controller = new Bank_Controller();

	private String fname;
	private String lname;
	private String dateStr;
	private String phoneno;
	private String adharno;
	private String gender;
	private String address;
	private String accno;
	private String pin1;
	private String pin2;
	private double balance;

	public void createAccount(String fname, String lname, String dateStr, String phoneno2, String adharno2,
			String gender, String address, String accno, String pin2, double balance2)
			throws ClassNotFoundException, SQLException {
		this.fname = fname;
		this.lname = lname;
		this.dateStr = dateStr;
		this.phoneno = phoneno2;
		this.adharno = adharno2;
		this.gender = gender;
		this.address = address;
		this.accno = accno;
		this.pin2 = pin2;
		this.balance = balance2;
		Connection connection = dataBase.getConnection();
		PreparedStatement ps = connection.prepareStatement("insert into account values(?,?,?,?,?,?,?,?,?,?)");
		ps.setString(1, fname);
		ps.setString(2, lname);
		ps.setString(3, dateStr);
		ps.setString(4, phoneno2);
		ps.setString(5, adharno2);
		ps.setString(6, gender);
		ps.setString(7, address);
		ps.setString(8, accno);
		ps.setString(9, pin2);
		ps.setDouble(10, balance2);
		int result = ps.executeUpdate();
		if (result != 0) {
			System.err.println("Data Inserted");
		} else {
			System.err.println("Not inserted");
		}
	}

	public boolean login(String acc_no) throws SQLException, ClassNotFoundException {
		Connection connection = dataBase.getConnection();
		PreparedStatement ps1 = connection.prepareStatement("select * from account where accno=?");
		ps1.setString(1, acc_no);
		ResultSet resultSet = ps1.executeQuery();
		if (resultSet.next()) {
			if (resultSet.getString("accno").equals(acc_no)) {
				System.out.println("Enter Pin");
				String pin = scanner.next();
				if (!validation.validPin(pin)) {
					System.err.println("Entered Pin number is invalid.");
					return false;
				} else {
					ps1 = connection.prepareStatement("select * from account where accno=? and pin2=?");
					ps1.setString(1, acc_no);
					ps1.setString(2, pin);
					ResultSet rs = ps1.executeQuery();
					if (rs.next()) {
						System.err.println("Pin is matched");
					} else {
						System.err.println("pin is not matching");
						return false;
					}
				}

			} else {
				System.err.println("Account number is wrong");
				return false;
			}

		} else {
			System.err.println("Create Account First");
			return false;
		}
		return true;
	}

	public void checkBalnace(String acc_no) throws ClassNotFoundException, SQLException {
		Connection connection = dataBase.getConnection();
		PreparedStatement ps1 = connection.prepareStatement("select * from account where accno=?");
		ps1.setString(1, acc_no);
		ResultSet resultSet = ps1.executeQuery();
		if (resultSet.next()) {
			System.out.println("Enter correct Pin");
			String pin = scanner.next();
			if (!validation.validPin(pin)) {
				System.err.println("Entered Pin number is invalid.");
			} else {
				ps1 = connection.prepareStatement("select * from account where accno=? and pin2=?");
				ps1.setString(1, acc_no);
				ps1.setString(2, pin);
				resultSet = ps1.executeQuery();
				if (resultSet.next()) {
					System.out.println(resultSet.getDouble("balance"));
				} else {
					System.err.println("You Entered wrong pin");
				}
			}
		} else {
			System.err.println("First create Account");
		}
	}

	public void depositMoney(String acc_no) throws ClassNotFoundException, SQLException {

		Connection connection = dataBase.getConnection();
		PreparedStatement ps = connection.prepareStatement("select * from account where accno=?");
		ps.setString(1, acc_no);
		ResultSet resultSet = ps.executeQuery();
		if (resultSet.next()) {
			System.out.println("Enter correct pin");
			String pin = scanner.next();
			if (!validation.validPin(pin)) {
				System.err.println("Entered Pin number is invalid.");
			} else {
				ps = connection.prepareStatement("select * from account where accno=? and pin2=?");
				ps.setString(1, acc_no);
				ps.setString(2, pin);
				resultSet = ps.executeQuery();
				if (resultSet.next()) {
					System.out.println("Enter Money");
					double money = scanner.nextDouble();
					if (money > 0.0) {
						balance = resultSet.getDouble("balance") + money;
						ps = connection.prepareStatement("update account set balance=? where accno=?");
						ps.setDouble(1, balance);
						ps.setString(2, acc_no);
						int i = ps.executeUpdate();
						if (i != 0) {
							System.out.println("After depositing money = " + balance);
							Date currentDate = new Date();
							Timestamp currentTimestamp = new Timestamp(currentDate.getTime());

							ps = connection.prepareStatement("insert into credit(accno,credit,date)values(?,?,?)");
							ps.setString(1, acc_no);
							ps.setDouble(2, money);
							ps.setTimestamp(3, currentTimestamp);
							ps.execute();

							System.out.println("Deposited Successfully");
						} else {
							System.out.println("Not Deposited");
						}
					} else {
						System.err.println("Withdrawal amount exceeded account balance");
					}
				} else {
					System.err.println("Incorrect pin");
				}
			}
		}
	}

	public void withdrawMoney(String acc_no) throws ClassNotFoundException, SQLException {
		Connection connection = dataBase.getConnection();
		PreparedStatement ps = connection.prepareStatement("select * from account where accno=?");
		ps.setString(1, acc_no);
		ResultSet resultSet = ps.executeQuery();
		if (resultSet.next()) {
			System.out.println("Enter correct pin");
			String pin = scanner.next();
			if (!validation.validPin(pin)) {
				System.err.println("Entered Pin number is invalid.");
			} else {
				ps = connection.prepareStatement("select * from account where accno=? and pin2=?");
				ps.setString(1, acc_no);
				ps.setString(2, pin);
				resultSet = ps.executeQuery();
				if (resultSet.next()) {
					System.out.println("Enter Money");
					double money = scanner.nextDouble();
					double balance2 = resultSet.getDouble("balance");

					if (!(money > 0.0)) {
						System.out.println("You have to enter money above 0");

					} else if (money > balance2) {
						System.err.println("Withdrawal amount exceeded account balance");
					} else {
						balance = resultSet.getDouble("balance") - money;
						ps = connection.prepareStatement("update account set balance=? where accno=?");
						ps.setDouble(1, balance);
						ps.setString(2, acc_no);
						int i = ps.executeUpdate();
						if (i > 0) {
							System.out.println("After withdraw money = " + money);
							Date currentDate = new Date();
							Timestamp currentTimestamp = new Timestamp(currentDate.getTime());

							ps = connection.prepareStatement("insert into withdraw(accno,withdraw,date)values(?,?,?)");
							ps.setString(1, acc_no);
							ps.setDouble(2, money);
							ps.setTimestamp(3, currentTimestamp);

							ps.execute();
							System.err.println("Withdraw Successfully !!");
						} else {
							System.out.println("Not withdraw");
						}
					}
				} else {
					System.err.println("You Entered wrong pin");
				}
			}
		}
	}

	public void showDetails(String accno1) throws SQLException, ClassNotFoundException {
		Connection connection = dataBase.getConnection();
		PreparedStatement ps1 = connection.prepareStatement("select * from account where accno=?");
		ps1.setString(1, accno1);
		ResultSet resultSet = ps1.executeQuery();
		if (resultSet.next()) {
			System.out.println("Enter correct Pin");
			String pin = scanner.next();
			if (!validation.validPin(pin)) {
				System.err.println("Entered Pin number is invalid.");
			} else {
				ps1 = connection.prepareStatement("select * from account where accno=? and pin2=?");
				ps1.setString(1, accno1);
				ps1.setString(2, pin);
				resultSet = ps1.executeQuery();
				if (resultSet.next()) {
					System.err.println("Show Details of " + accno);
					System.out.println("First Name = " + resultSet.getString("fname"));
					System.out.println("Last Name = " + resultSet.getString("lname"));
					System.out.println("DOB = " + resultSet.getString("dateStr"));
					System.out.println("Phone Number = " + resultSet.getString("phoneno"));
					System.out.println("Adhar Number = " + resultSet.getString("adharno"));
					System.out.println("Gender = " + resultSet.getString("gender"));
					System.out.println("Address = " + resultSet.getString("address"));
					System.out.println("balance = " + resultSet.getString("balance"));
				} else {
					System.err.println("You Entered wrong pin");
				}
			}
		} else {
			System.err.println("First create Account");
		}
	}

	public void transferMoney(String accno1, double trnsferMoney) throws SQLException, ClassNotFoundException {

		Connection connection = dataBase.getConnection();
		PreparedStatement ps = connection.prepareStatement("select * from account where accno=?");
		ps.setString(1, accno1);
		ResultSet resultSet = ps.executeQuery();
		if (resultSet.next()) {

			if (!(trnsferMoney > 0.0)) {
				System.out.println("You have to enter money above 0");

			} else {
				double updateBalance = resultSet.getDouble("balance") + trnsferMoney;
				ps = connection.prepareStatement("update account set balance=? where accno=?");
				ps.setDouble(1, updateBalance);
				ps.setString(2, accno1);
				int result = ps.executeUpdate();
				if (result > 0) {
					Date currentDate = new Date();
					Timestamp currentTimestamp = new Timestamp(currentDate.getTime());

					ps = connection.prepareStatement("insert into credit(accno,credit,date)values(?,?,?)");
					ps.setString(1, accno1);
					ps.setDouble(2, trnsferMoney);
					ps.setTimestamp(3, currentTimestamp);
					ps.execute();

					System.err.println("Transfered Amount Successfully !! ");
				}
			}
		} else {
			System.out.println("Account number is not there ");
		}
	}

	public void decMoney(String accno1, double trnsferMoney) throws SQLException, ClassNotFoundException {

		Connection connection = dataBase.getConnection();
		PreparedStatement ps = connection.prepareStatement("select * from account where accno=?");
		ps.setString(1, accno1);
		ResultSet resultSet = ps.executeQuery();
		if (resultSet.next()) {
			double balance2 = resultSet.getDouble("balance");
			if (trnsferMoney > 0 || trnsferMoney < balance2) {
				double decMoney = resultSet.getDouble("balance") - trnsferMoney;
				ps = connection.prepareStatement("update account set balance=? where accno=?");
				ps.setDouble(1, decMoney);
				ps.setString(2, accno1);
				int i = ps.executeUpdate();
				if (i > 0) {
					Date currentDate = new Date();
					Timestamp currentTimestamp = new Timestamp(currentDate.getTime());

					ps = connection.prepareStatement("insert into debit(accno,debit,date)values(?,?,?)");
					ps.setString(1, accno1);
					ps.setDouble(2, trnsferMoney);
					ps.setTimestamp(3, currentTimestamp);
					ps.execute();

				}
			} else {
				System.err.println("Withdrawal amount exceeded account balance");
			}
		} else {
			System.out.println("Account is not found");
		}
	}

	public void miniStatement(String accno2) throws ClassNotFoundException, SQLException {
		Connection connection = dataBase.getConnection();
		PreparedStatement ps = connection.prepareStatement("select * from debit where accno=? order by date desc");
		ps.setString(1, accno2);
		System.err.println("      Money		" + "|" + "          Date and Time");
		ResultSet resultSet = ps.executeQuery();
		while (resultSet.next()) {
			System.out
					.print("Debited Money " + resultSet.getDouble("debit") + "\t|\t" + resultSet.getTimestamp("date"));
			System.out.println();
		}

		ps = connection.prepareStatement("select * from withdraw where accno=? order by date desc");
		ps.setString(1, accno2);

		resultSet = ps.executeQuery();
		while (resultSet.next()) {
			System.out.print(
					"Withdrawed Money " + resultSet.getDouble("withdraw") + "\t|\t" + resultSet.getTimestamp("date"));
			System.out.println();

		}
		ps = connection.prepareStatement("select * from credit where accno=? order by date desc");
		ps.setString(1, accno2);

		resultSet = ps.executeQuery();
		while (resultSet.next()) {
			System.out.print(
					"credited Money " + resultSet.getDouble("credit") + "\t|\t" + resultSet.getTimestamp("date"));
			System.out.println();

		}
		System.out.println();

	}
}
