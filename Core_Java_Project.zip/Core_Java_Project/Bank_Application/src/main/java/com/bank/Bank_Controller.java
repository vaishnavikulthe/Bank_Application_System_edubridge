package com.bank;

import java.util.Date;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import java.util.Scanner;

public class Bank_Controller {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Scanner scanner = new Scanner(System.in);
		BankDao dao = new BankDao();
		Validation validation = new Validation();
		String accno;
		UpdateAccountDetails details = new UpdateAccountDetails();
		System.err.println(">>>>>>>>>>>>> Banking Application <<<<<<<<<<<<<");
		for (;;) {
			System.out.println("==========================");
			System.out.println("Enter Choice \n1. Create Account \n2. Login Account");
			System.out.println("==========================");
			switch (scanner.nextInt()) {
			case 1: {
				System.out.println("Enter First Name");
				String fname = scanner.next();
				System.out.println("Enter Last Name");
				String lname = scanner.next();
				System.out.println("Enter Your Date of Birth (dd/mm/yyyy):");
				String dateStr = scanner.next();
				SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
				try {
					Date date = (Date) sdf.parse(dateStr);
				} catch (ParseException e) {
					System.err.println("Invalid date format");
					break;
				}
				System.out.println("Enter Mobile number");
				String phoneno = scanner.next();
				if (!validation.validNo(phoneno)) {
					System.out.println("Entered mobile number is invalid.");
					break;
				}
				System.out.println("Enter Adhar Number");
				String adharno = scanner.next();
				if (validation.validAdharNumber(adharno)) {
					System.err.println("Entered Adhar Number is Invalid.");
					break;
				}
				System.out.println("Enter your Gender");

				System.out.println("F .Female \t M .Male \t O .other");
				String gender = scanner.next().toLowerCase();
				switch (gender) {
				case "f": {
					gender = "Female";
					System.out.println(gender);
					break;
				}
				case "m": {
					gender = "Male";
					System.out.println(gender);
					break;
				}
				case "o": {
					gender = "Other";
					System.out.println(gender);
					break;
				}

				default: {
					System.out.println("Invalid Input");
				}
				}

				scanner.nextLine();
				System.out.println("Enter Address");
				String address = scanner.next();
				scanner.nextLine();
				System.out.println("Enter Accountno");
				accno = scanner.next();
				if (!validation.validAccno(accno)) {
					System.out.println("Entered Account number is invalid.");
					break;
				}
				System.out.println("Enter pin");
				String pin1 = scanner.next();
				if (!validation.validPin(pin1)) {
					System.err.println("Entered Pin number is invalid.");
					break;
				} else {
					System.out.println("Re-Enter Pin");
					String pin2 = scanner.next();
					if (!validation.validPin(pin2)) {
						System.err.println("Entered Pin number is invalid.");
						break;
					} else {
						if (!(pin1.equals(pin2))) {
							System.err.println("Pins do not match.");
							break;
						} else {
							System.out.println("Enter Initial Balance which is above 500");
							double balance = scanner.nextDouble();
							if (balance >= 500) {
								dao.createAccount(fname, lname, dateStr, phoneno, adharno, gender, address, accno, pin2,
										balance);
								System.err.println("Account Created Successfully");
							} else {
								System.err.println("Required 500% or above");
							}
						}
					}
				}
				break;
			}

			case 2: {
				System.out.println("Enter Account No");
				accno = scanner.next();
				if (!validation.validAccno(accno)) {
					System.err.println("Entered Account number is invalid.");
					break;
				} else {
					boolean result = dao.login(accno);
					if (!result)
						break;
					else {
						while (true) {
							System.out.println("***************************************************************");
							System.out.println(
									" 1.Check Balance\n 2.Deposit Money\n 3.Withdraw Money\n 4.Money Transfer \n 5.Mini Statement\n 6.Update\n 7.Show Details\n");
							System.out.println("***************************************************************");
							switch (scanner.nextInt()) {
							case 1: {
								System.out.println("Enter account no");
								String accno1 = scanner.next();
								if (!validation.validAccno(accno1)) {
									System.err.println("Entered Account number is invalid.");
									break;
								} else {
									if (accno.equals(accno1)) {
										dao.checkBalnace(accno);
									} else {
										System.err.println("Account number is not matchable");
									}
								}
								break;
							}
							case 2: {
								System.out.println("Enter Correct Account Number");
								String accno1 = scanner.next();
								if (!validation.validAccno(accno1)) {
									System.err.println("Entered Account number is invalid.");
									break;
								} else {
									if (accno.equals(accno1)) {
										dao.depositMoney(accno1);
									} else {
										System.err.println("Account number is not matchable");
									}
								}
								break;
							}
							case 3: {
								System.out.println("Enter Correct Account Number");
								String accno1 = scanner.next();
								if (!validation.validAccno(accno1)) {
									System.err.println("Entered Account number is invalid.");
									break;
								} else {
									if (accno.equals(accno1)) {
										dao.withdrawMoney(accno1);
									} else {
										System.err.println("Account number is not matchable");
									}
								}
								break;
							}
							case 4: {
								System.out.println(
										"Enter Correct Account Number for Transfering Money to another one Account");
								String accno1 = scanner.next();

								if (!validation.validAccno(accno1)) {
									System.err.println("Entered Account number is invalid.");
									break;
								} else {
									if (!accno.equals(accno1)) {
										System.out.println("Enter Amount for Transfering");
										double trnsferMoney = scanner.nextDouble();
										dao.transferMoney(accno1, trnsferMoney);
										dao.decMoney(accno, trnsferMoney);

									} else {
										System.err.println("You Cannot Enter same Account Number");
									}
								}
								break;

							}
							case 5: {
								dao.miniStatement(accno);
								break;
							}
							case 6: {
								System.out.println("Enter Correct Account Number");
								String accno1 = scanner.next();
								if (!validation.validAccno(accno1)) {
									System.err.println("Entered Account number is invalid.");
									break;
								} else {
									if (accno.equals(accno1)) {
										System.err.println(
												"Choose options \n1. update First Name\n2. Update Last Name \n3. Update Date of Birth\n4. Update Phone Number\n5. Update Address\n6. Update Pin \n");
										switch (scanner.nextInt()) {
										case 1: {
											details.updateFirstname(accno1);
											break;
										}
										case 2: {
											details.updateLastname(accno1);
											break;
										}
										case 3: {
											details.updateDob(accno1);
											break;
										}
										case 4: {
											details.updatePhoneNo(accno1);
											break;
										}
										case 5: {
											details.updateAddress(accno1);
											break;
										}
										case 6: {
											details.updatePin(accno1);
											break;
										}
										case 7: {
											break;
										}
										default: {
											System.out.println("Invalid Input");
											break;
										}
										}
									} else {
										System.err.println("Account number is not matchable please Login");
									}
								}
								break;
							}
							case 7: {
								System.out.println("Enter Correct Account Number");
								String accno1 = scanner.next();
								if (!validation.validAccno(accno1)) {
									System.err.println("Entered Account number is invalid.");
									break;
								} else {
									if (accno.equals(accno1)) {
										dao.showDetails(accno1);
									} else {
										System.err.println("Account number is not matchable");
									}
								}
								break;
							}

							default: {
								System.err.println("Invalid input");
							}
							}
							System.out.println("Do you want to continue , y to continue, any other key to stop ");
							char choice = scanner.next().toLowerCase().charAt(0);
							if (choice != 'y') {
								break;
							} else {
								continue;
							}
						}
					}
				}
				break;
			}
			default: {
				System.err.println("Invalid input");
			}
			}
		}
	}
}
