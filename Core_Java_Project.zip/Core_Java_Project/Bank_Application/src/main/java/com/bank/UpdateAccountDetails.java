package com.bank;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class UpdateAccountDetails {
	Scanner scanner = new Scanner(System.in);
	DataBase dataBase = new DataBase();
	BankDao dao = new BankDao();
	Validation validation = new Validation();

	public void updateFirstname(String accno1) throws ClassNotFoundException, SQLException {
		Connection connection = dataBase.getConnection();
		PreparedStatement ps = connection.prepareStatement("select * from account where accno=?");
		ps.setString(1, accno1);
		ResultSet resultSet = ps.executeQuery();
		if (resultSet.next()) {
			System.out.println("Enter Pin");
			String pin = scanner.next();
			if (!validation.validPin(pin)) {
				System.out.println("Entered Pin number is invalid.");
			} else {
				ps = connection.prepareStatement("select * from account where accno=? and pin2=?");
				ps.setString(1, accno1);
				ps.setString(2, pin);
				resultSet = ps.executeQuery();
				if (resultSet.next()) {
					System.out.println("Enter New First Name");
					String newfname = scanner.next();

					ps = connection.prepareStatement("update account set fname=? where accno=?");
					ps.setString(1, newfname);
					ps.setString(2, accno1);
					int i = ps.executeUpdate();
					if (i != 0) {
						System.out.println("Updated First Name");
					} else {
						System.err.println("Not Updated First name");
					}
				} else {
					System.out.println("Pin is wrong");
				}
			}
		}

	}

	public void updateLastname(String accno1) throws ClassNotFoundException, SQLException {
		Connection connection = dataBase.getConnection();
		PreparedStatement ps = connection.prepareStatement("select * from account where accno=?");
		ps.setString(1, accno1);
		ResultSet resultSet = ps.executeQuery();
		if (resultSet.next()) {
			System.out.println("Enter Pin");
			String pin = scanner.next();
			if (!validation.validPin(pin)) {
				System.out.println("Entered Pin number is invalid.");

			} else {
				ps = connection.prepareStatement("select * from account where accno=? and pin2=?");
				ps.setString(1, accno1);
				ps.setString(2, pin);
				resultSet = ps.executeQuery();
				if (resultSet.next()) {
					System.out.println("Enter New Last Name");
					String newlname = scanner.next();

					ps = connection.prepareStatement("update account set lname=? where accno=?");
					ps.setString(1, newlname);
					ps.setString(2, accno1);
					int i = ps.executeUpdate();
					if (i != 0) {
						System.out.println("Updated Last Name");
					} else {
						System.err.println("Not Updated Last name");
					}
				} else {
					System.out.println("Pin is wrong");
				}
			}
		}

	}

	public void updatePin(String accno1) throws SQLException, ClassNotFoundException {
		Connection connection = dataBase.getConnection();
		PreparedStatement ps = connection.prepareStatement("select * from account where accno=?");
		ps.setString(1, accno1);
		ResultSet resultSet = ps.executeQuery();
		if (resultSet.next()) {
			System.out.println("Enter Pin");
			String pin = scanner.next();
			if (!validation.validPin(pin)) {
				System.err.println("Entered Pin number is invalid.");
			} else {
				ps = connection.prepareStatement("select * from account where accno=? and pin2=?");
				ps.setString(1, accno1);
				ps.setString(2, pin);
				resultSet = ps.executeQuery();
				if (resultSet.next()) {
					System.out.println("Enter New Pin");
					String newpin = scanner.next();

					ps = connection.prepareStatement("update account set pin2=? where accno=?");
					ps.setString(1, newpin);
					ps.setString(2, accno1);
					int i = ps.executeUpdate();
					if (i != 0) {
						System.out.println("Updated New Pin");
					} else {
						System.err.println("Not Updated pin");
					}
				} else {
					System.err.println("Pin is wrong");
				}
			}
		}

	}

	public void updateAddress(String accno1) throws ClassNotFoundException, SQLException {
		Connection connection = dataBase.getConnection();
		PreparedStatement ps = connection.prepareStatement("select * from account where accno=?");
		ps.setString(1, accno1);
		ResultSet resultSet = ps.executeQuery();
		if (resultSet.next()) {
			System.out.println("Enter Pin");
			String pin = scanner.next();
			if (!validation.validPin(pin)) {
				System.err.println("Entered Pin number is invalid.");

			} else {
				ps = connection.prepareStatement("select * from account where accno=? and pin2=?");
				ps.setString(1, accno1);
				ps.setString(2, pin);
				resultSet = ps.executeQuery();
				if (resultSet.next()) {
					System.out.println("Enter New Address");
					String newAddress = scanner.next();

					ps = connection.prepareStatement("update account set address=? where accno=?");
					ps.setString(1, newAddress);
					ps.setString(2, accno1);
					int i = ps.executeUpdate();
					if (i != 0) {
						System.err.println("Updated Address");
					} else {
						System.err.println("Not Updated Address");
					}
				} else {
					System.err.println("Pin is wrong");
				}
			}
		}

	}

	public void updatePhoneNo(String accno1) throws ClassNotFoundException, SQLException {
		Connection connection = dataBase.getConnection();
		PreparedStatement ps = connection.prepareStatement("select * from account where accno=?");
		ps.setString(1, accno1);
		ResultSet resultSet = ps.executeQuery();
		if (resultSet.next()) {
			System.out.println("Enter Pin");
			String pin = scanner.next();

			if (!validation.validPin(pin)) {
				System.err.println("Entered Pin number is invalid.");

			} else {
				ps = connection.prepareStatement("select * from account where accno=? and pin2=?");
				ps.setString(1, accno1);
				ps.setString(2, pin);
				resultSet = ps.executeQuery();
				if (resultSet.next()) {
					System.out.println("Enter New Phone Number");
					String newPhone = scanner.next();
					if (validation.validNo(newPhone)) {
						ps = connection.prepareStatement("update account set phoneno=? where accno=?");
						ps.setString(1, newPhone);
						ps.setString(2, accno1);
						int i = ps.executeUpdate();
						if (i != 0) {
							System.err.println("Updated phone Number");
						} else {
							System.err.println("Not Updated Phone number");
						}
					} else {
						System.err.println("Invalid Phone Number");
						return;
					}
				} else {
					System.err.println("Pin is wrong");
				}
			}
		}
	}

	public void updateDob(String accno1) throws SQLException, ClassNotFoundException {
		Connection connection = dataBase.getConnection();
		PreparedStatement ps = connection.prepareStatement("select * from account where accno=?");
		ps.setString(1, accno1);
		ResultSet resultSet = ps.executeQuery();
		if (resultSet.next()) {
			System.out.println("Enter Pin");
			String pin = scanner.next();
			if (!validation.validPin(pin)) {
				System.err.println("Entered Pin number is invalid.");
			} else {
				ps = connection.prepareStatement("select * from account where accno=? and pin2=?");
				ps.setString(1, accno1);
				ps.setString(2, pin);
				resultSet = ps.executeQuery();
				if (resultSet.next()) {
					System.out.println("Enter New DOB");
					String newDate = scanner.next();
					SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
					try {
						Date date = (Date) sdf.parse(newDate);
						ps = connection.prepareStatement("update account set dateStr=? where accno=?");
						ps.setString(1, newDate);
						ps.setString(2, accno1);
						ps.executeUpdate();
						System.err.println("updated Successfully");
					} catch (ParseException e) {
						System.err.println("Invalid date format");
						return;
					}
				} else {
					System.err.println("Pin is wrong");
				}
			}
		}
	}
}
