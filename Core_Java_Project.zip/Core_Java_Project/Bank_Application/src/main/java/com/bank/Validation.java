package com.bank;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Validation {
	/*Bank Account Number is written only in numeric form.
	Bank Account number length varies from 9 digits to 18 digits.
	No Whitespaces are allowed.
	Special characters are not allowed.
	It contains numbers from 0 to 9.*/
	
	public boolean validNo(String phoneno2) {
		Pattern ptrn = Pattern.compile("[6-9][0-9]{9}");  
		//the matcher() method creates a matcher that will match the given input against this pattern  
		Matcher match = ptrn.matcher(phoneno2);  
		//returns a boolean value  
		return (match.find() && match.group().equals(phoneno2));
	}
	
	 public boolean validAccno(String accountno)
	    {
	        String regex = "^[0-9]{12}$";
	        Pattern p = Pattern.compile(regex);
	        Matcher m = p.matcher(accountno);
	        if (m.matches())
	            return true;
	        return false;
	    }
	 public boolean validPin(String pin)
	    {
		 return pin.matches("\\d{4}");
	    }
	 /*represents the starting of the string.
	 [2-9]{1} represents the first digit should be any from 2-9.
	 [0-9]{3} represents the next 3 digits after the first digit should be any digit from 0-9.
	 \\s represents white space.
	 [0-9]{4} represents the next 4 digits should be any from 0-9.
	 \\s represents white space.
	 [0-9]{4} represents the next 4 digits should be any from 0-9.
	 $ represents the ending of the string. */
	 public boolean validAdharNumber(String adharno)
	    {
	        // Regex to check valid Aadhaar number.
	        String regex = "^[2-9]{1}[0-9]{3}\\s[0-9]{4}\\s[0-9]{4}$";
	 
	        // Compile the ReGex
	        Pattern p = Pattern.compile(regex);
	        // Pattern class contains matcher() method
	        // to find matching between given string
	        // and regular expression.
	        Matcher m = p.matcher(adharno);
	        // Return if the string
	        // matched the ReGex
	        return m.matches();
	    }
	 

}
